const mongoose = require("mongoose")

module.exports = () => {
    return mongoose.connect("mongodb://localhost:27017/web_14")
}









// db ------> mongodb://localhost:27017/evaluation_4

// --------------atlast  link --------------
//mongodb+srv://ajit:<password>@cluster0.j9h3s.mongodb.net/